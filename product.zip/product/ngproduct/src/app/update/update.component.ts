import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { Router } from '@angular/router';
import { ProductModel } from '../list/list.model';
import { ActivatedRoute } from '@angular/router';


import { from } from 'rxjs';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {

  constructor(private productService:ProductService,
    private router:Router,
    private _route:ActivatedRoute) { }
    UpdateItem= new ProductModel(null,null,null,null,null,null,null,null);


  ngOnInit(): void {
    let id=this._route.snapshot.paramMap.get("id")
    const ID={id:id};
    this.productService.getUpdate(ID)
    .subscribe((data)=>{
      this.UpdateItem=JSON.parse(JSON.stringify(data))
    })
  }
  updateProduct(){
    let id=this._route.snapshot.paramMap.get("id")
    const ID={id:id};
    this.productService.updateProduct(ID,this.UpdateItem)
    alert('updated');
    this.router.navigate(['list'])
  }



}
