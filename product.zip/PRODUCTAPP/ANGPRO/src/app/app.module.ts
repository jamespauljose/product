import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { ProductlistComponent } from './productlist/productlist.component';
import { LoginComponent } from './login/login.component';
import { HeaderComponent } from './header/header.component';
import { HttpClientModule } from '@angular/common/http';
import { NewproductComponent } from './newproduct/newproduct.component';
import { UpdateComponent } from './update/update.component';
import { SignupComponent } from './signup/signup.component';
import {AuthGuard} from'./auth.guard';
import { AuthService } from './auth.service';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    ProductlistComponent,
    LoginComponent,
    
    HeaderComponent,
    NewproductComponent,
    UpdateComponent,
    SignupComponent,
  
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    

  ],
  providers: [AuthService,AuthGuard],

    bootstrap: [AppComponent]
})
export class AppModule { }
