import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ProductModel } from '../list/list.model';
import { ProductService } from '../product.service';


import { from } from 'rxjs';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  constructor(private productService:ProductService,
    private router:Router) { }
  productItem= new ProductModel(null,null,null,null,null,null,null,null)

  ngOnInit(): void {
  }
  AddProduct(){
    this.productService.product(this.productItem)
    alert("success");
    this.router.navigate(['list'])
  }

}
