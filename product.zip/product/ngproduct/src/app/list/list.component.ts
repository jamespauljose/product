import { Component, OnInit } from '@angular/core';
import { ProductModel } from './list.model';
import { ProductService} from '../product.service';

import { from } from 'rxjs';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {
  products:ProductModel[];
  imageWidth :number=50;
  imageMargin :number=2;
  ShowImage: boolean=false;


  constructor(private productService:ProductService) { }
  img():void{
    this.ShowImage=!this.ShowImage;
  
  }

  del(_id):void{
    this.productService.deleteProduct(_id)
    .subscribe((data)=>{
      this.products=JSON.parse(JSON.stringify(data))
    })
  }
  ngOnInit(): void {
    this.productService.getProducts()
    .subscribe((data)=>{
      this.products=JSON.parse(JSON.stringify(data));

    })
  }


}
