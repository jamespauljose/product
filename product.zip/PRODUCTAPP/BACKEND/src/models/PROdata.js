const mongoose=require("mongoose")
mongoose.connect('mongodb://localhost:27017/PROdb');
const Schema=mongoose.Schema

const PROSchema=new Schema({

    
    productId:String,
    productName:String,
    productCode:String,
    price:Number,
    starRating:Number,
    imageUrl:String,
    releaseDate:String,
    description:String,
   
});

var PROdata=mongoose.model('Product',PROSchema)

module.exports=PROdata;