const mongoose = require("mongoose");
mongoose.connect('mongodb://localhost:27017/productdb');
const Schema = mongoose.Schema
const signSchema = new Schema({
    email:String,
    password:String
});
const signdata = mongoose.model('signdata',signSchema)
module.exports = signdata;