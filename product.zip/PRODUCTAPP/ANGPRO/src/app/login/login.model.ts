export class LoginModel{
    constructor(
     
        public email:String,
        public password:String
        
){}

}