export class ProductModel{
    constructor(
        public productId:String,
        public price:Number,
        public starRating:Number,
        public productName:String,
        public releaseDate:String,
        public productCode:String,
        public description:String,
        public imageUrl:String
        ){}
}