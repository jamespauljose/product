const express=require('express');
const router = express.Router();
const productdata = require('./models/productdata');
// const signdata = require('./models/signdata');

router.get('/list', (req,res)=>{
    productdata.find()
    .then((product)=>{
        res.send(product)
    });
    
})
router.post('/updatelist',(req,res)=>{

    console.log("updatelist")
    id=req.body.ID.id;
    console.log(id);
    productdata.findById({_id:id})
    .then((product)=>{
        res.send(product)
    });

})

router.post('/insert',(req,res)=>{
    var product ={
        productId:req.body.product.productId,
        productName:req.body.product.productName,
        productCode:req.body.product.productCode,
        price:req.body.product.price,
        starRating:req.body.product.starRating,
        imageUrl:req.body.product.imageUrl,
        releaseDate:req.body.product.releaseDate,
        description:req.body.product.description,

    }
    var product=new productdata(product);
    product.save();
})
router.post('/delete', (req,res)=>{
    id=req.body.id;
    console.log('delete');
    id= req.body.id;
    console.log(id)
    productdata.findByIdAndDelete({_id:id})
    .then(()=>{
        console.log("deleted")
        productdata.find()
        .then((product)=>{res.send(product)})
        
    })
})
router.post('/update',(req,res)=>{
    
    id=req.body.ID.id;
    console.log("update");
    console.log(id);
    
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Methods: GET, POST,PUT, PATCH, DELETE, OPTIONS");
  
    productdata.findByIdAndUpdate({_id:id},{
        productId:req.body.product.productId,
        productName:req.body.product.productName,
        productCode:req.body.product.productCode,
        price:req.body.product.price,
        starRating:req.body.product.starRating,
        imageUrl:req.body.product.imageUrl,     
        releaseDate:req.body.product.releaseDate, 
        description:req.body.product.description},(err,doc)=>{
            if(err)console.log(err)
        })
    })


module.exports= router;