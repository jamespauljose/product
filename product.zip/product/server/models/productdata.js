const mongoose=require('mongoose');
mongoose.connect('mongodb://localhost:27017/productdb');
const Schema = mongoose.Schema
const productSchema = new Schema({
       
    productId:String,
    productName:String,
    productCode:String,
    price:Number,
    starRating:Number,
    imageUrl:String,
    releaseDate:String,
    description:String,
});

var productdata=mongoose.model('Product',productSchema)

module.exports = productdata;