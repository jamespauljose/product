import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { from } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor(private http:HttpClient) { }
  getProducts(){
    return this.http.get("http://localhost:3000/api/list")
  }
  product(item){
    return this.http.post("http://localhost:3000/api/insert",{"product":item})
    .subscribe(data=>{console.log(data)})
  }
  deleteProduct(_id){return this.http.post("http://localhost:3000/api/delete",{"id":_id})}

  updateProduct(ID,UpdateItem){
    return this.http.post("http://localhost:3000/api/update",{"product":UpdateItem,"ID":ID})
    .subscribe((data)=>{console.log(data)})
  }
  getUpdate(ID){
    return this.http.post("http://localhost:3000/api/updatelist",{"ID":ID})
    // console.log(ID)
  }

}
